class a:

    def test(self):
        self.i = input('enter dat :')
        self.name = input('enter dat :')

    def show(self):
        print(self.i,self.name)
        



l = []

for x in range(10):
    o = a()
    o.test()
    l.append(o)


##
l[1].show()

for x in l:
    x.show()
    

