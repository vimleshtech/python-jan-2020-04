#Sample App
student= [] #empty list

while True: #infinte
    ch = input('press 1 to add new row, 2 for show all 3 for delete 4 for update and 0 of exist')
    
    if ch =='1':
        print('in add')
        row  = [] #empty list
        sid = input('enter sid :')
        sname = input('enter sname :')
        fee = input('enter fee :')
        subject = input('enter sub ')

        #create row 
        row.append(sid)
        row.append(sname)
        row.append(fee)
        row.append(subject)
        
        print(row)
        #push row to table 
        student.append(row)
        

    elif ch=='2':
        for s in student:
            print(s)
            


    elif ch=='3':
        print('in del')
        eid = input('enter sid to remove ')

        m= []
        for s in student:
            if s[0] == eid:
                m = s


        if len(m)>0:
            student.remove(m)
        else:
            print('given sid is not match ')       
                


    elif ch=='4':
        print('in update')
        eid = input('enter sid which you want to update')
        for i in range(len(student)):
            
            if student[i][0] == eid:
                name = input('enter new name ')
                fee   = input('enter new fee ')
                sub   = input('enter new sub')
                
                student[i][1] =  name
                student[i][2] =  fee
                student[i][3] =  sub
                
        
        

    elif ch=='0':
        break  #stop / terminate the loop 
    else:
        print('invalid choice !!!')
