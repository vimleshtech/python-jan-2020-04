#two d list

a = [[11,23,44,56],[3,3,4,5],[11,23,44,56],[11,23,44,56],[11,23,44,56]]

print('row len ', len(a))


for row in a:
    print(row)


#read row and col
for r in a: #table to row
    for c in r: #row to column
        print(c,end='') #don't change line
    print() #new line
    
        


