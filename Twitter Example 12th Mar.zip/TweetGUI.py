from tkinter import *

o = Tk()


lbl = Label(text='enter leader name :')
lbl.pack()

txt=  Entry()
txt.pack()



out = Text()
out.pack()

def find_tweet():
    print('you have clicked on find tweet ')
    
find = Button(text='Search',command=find_tweet)
find.pack()


o.mainloop()
