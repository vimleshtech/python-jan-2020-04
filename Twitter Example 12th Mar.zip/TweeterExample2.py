import tweepy
from tweepy import OAuthHandler 

import re # regular expression
from textblob import TextBlob #text/tweet parse

ck="Jm6WDXZuiwlwUnT9mFbPdSpcg"
cs="Wp4Gbf74R6MZWjXvj0ifKrCobwWbchhn53Mv8L7VMLbIUi6Wnd"
at="919434545924935681-wFjVVTbs0pmyB2VwSoj4VwGb7tBYCyr"
ats ="RaPfxU0rSMjkS3MSI9N0ztXu4I2iLMecXg79OerNHw4Ly"

auth = OAuthHandler(ck, cs)
# set access token and secret
auth.set_access_token(at, ats)

# create tweepy API object to fetch tweets
api = tweepy.API(auth)


def clean_tweet(txt):
    return ' '.join(re.sub("(@[A-Za-z0-9]+)|([^0-9A-Za-z \t]) |(\w+:\/\/\S+)", " ", txt).split())


def get_sentiment(txt):

    res = ''
    ana = TextBlob(txt)

    if ana.sentiment.polarity>0:
        res='positive'

    elif ana.sentiment.polarity<0:
        res='negative'
    else:
        res='neutral'


    return res
    

    
def get_tweet(name,c=10):
    t = api.search(q=name,count=c)

    print('---------------------',name,'-----------------------')
    res = []
    for tweet in t:
        #print(tweet.source,tweet.created_at)
        #print(tweet.text.encode())
        try:
            #print(clean_tweet(tweet.text))
            #print(get_sentiment(tweet.text))
            res.append(get_sentiment(tweet.text))
            
        except:
            pass
        
    return res

#
leaders =['Sonia Gandhi','Narendra Modi','Rahul Gandhi']
for l in leaders:
    res = get_tweet(l)
    print(res)

    pos = [r for r in res if r =='positive']
    neg = [r for r in res if r =='negative']
    neu = [r for r in res if r =='neutral']

    print(pos, len(pos) ,  (len(pos)/ len(res))*.100)
    print(neg, len(neg) ,  (len(neg)/ len(res))*.100)
    print(neu, len(neu) ,  (len(neu)/ len(res))*.100)
    
    
    
    
    
    

    











	
