import tweepy
from tweepy import OAuthHandler 

#import re # regular expression
#from textblob import TextBlob #text/tweet parse


ck="Jm6WDXZuiwlwUnT9mFbPdSpcg"
cs="Wp4Gbf74R6MZWjXvj0ifKrCobwWbchhn53Mv8L7VMLbIUi6Wnd"
at="919434545924935681-wFjVVTbs0pmyB2VwSoj4VwGb7tBYCyr"
ats ="RaPfxU0rSMjkS3MSI9N0ztXu4I2iLMecXg79OerNHw4Ly"


auth = OAuthHandler(ck, cs)
# set access token and secret
auth.set_access_token(at, ats)

# create tweepy API object to fetch tweets
api = tweepy.API(auth)


#print(api)

t = api.search(q='Narendara Modi',count=100)

for tweet in t:
    print(tweet.source,tweet.created_at)
    print(tweet.text.encode())
    
    
    




	
