#while oop
i =1
while  i<=10:
    print(i)
    i=i+1


#print in reverse
i =10
while i>0:
    print(i)
    i =i-1
    
    
