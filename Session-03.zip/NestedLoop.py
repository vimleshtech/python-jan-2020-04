for x in range(1,5): #row 
    for y in range(1,4): # 
        print(y,end='')
    print() #new line 
    
        
'''
x = 1
    y 123

pattern:
1
12
123
1234
'''

#row 
for r in range(1,10): #from 1 to <5
    for c in range(1,r+1): #from 1 to 4
        print(c,end='') #end='' don't change line
    print() #new line 

'''
Reverse
1234
124
12
1
'''
for r in range(0,4): 
    for c in range(1,5-r):
        print(c,end='')
    print()


    





    
			
