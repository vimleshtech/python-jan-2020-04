#decalre list
sales = [111,33,5,67,433,6,7,5,3436]

print('max =  ',max(sales))
print('min =  ',min(sales))
print('sum =  ',sum(sales))
print('len =  ',len(sales))


print('count of 5  =',sales.count(5))

#extend : merge twolist
a= [11,33,5]
b = [55,6767,55]

print(a)
print(b)
a.extend(b)
print(a)


#####sort
a.sort()
print(a)

#slicer
print(a[0]) #first value
print(a[-1]) # last value
print(a[-2]) #2nd last

print(a[0:4]) #from 0 to 3
print(a[:4]) #from 0 to 3


print(a)
print(a[::])
print(a[::-1]) #in reverse : perint in reverse order 

##reverse : change the position of data 
a.reverse()
print(a)



#index
print(a.index(55))


##append
sales.append(100)
sales.append(500)

sales.append(10)
print(sales)

#pop
sales.pop()
sales.pop()
print(sales)

#insrt
sales.insert(2,3000)
print(sales)

#remove
sales.remove(3000)
print(sales)

#modify value
sales[2] = 6700
print(sales)


#iterate the list
for i in range(len(sales)):
    print(sales[i])
#or
for x in sales:
    print(x)
    


    
    





















