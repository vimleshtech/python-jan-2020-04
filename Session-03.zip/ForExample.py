for x in range(1,11):
    print(x)
    

#in reverse
for x in range(10,0,-1):
    print(x)
    
