
while True:
        name =  input('enter name :')

        if len(name) <5 or len(name)>10:
            print('invalid input , len should be between 5 to 10 ')
        else:
            print('you have entered ',name)
            break
        
    
