##
s = input('enter string :')
print(s[2:5])



###
'''
if s.index('is')>-1:
    print(s.index('is'))
else:
    print(0)
'''


##
o = s.split('is')
print(o)

if len(o)>1:
    print(len(o[0]))
else:
    print(0)


    
    


