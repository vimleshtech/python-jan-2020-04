'''WAP to count the number of spaces, tabs and new line
characters in a given string.'''


x =input('enter value of x')
print(x.count(' '))
print(x.count('\t'))
a=list(x)
if a[0].isupper():
    print('it is a new line')
else:print('it is not new line')




'''Question C2: WAP to input a character and a string.
Each occurrence of a character in the string
should be converted to opposite case i.e. upper to lower case or vice versa.'''

##print(x.swapcase())

y=input("enter a char")


i=0
while i<len(a):
    if a[i]==y:
        if a[i].isupper():
            a[i]=a[i].lower()
        else:
            a[i]=a[i].upper()
    i+=1
print(a)

'''WAP to count the number of words
and number of characters in a given line of
text except the spaces.'''

print(len(x.split(' ')))
print(len(a))
print(x.count('e'))


'''WAP to input a multi word string and produce a string in
which first letter of each word is capitalized.'''

print(x.title())



'''WAP to count the numbers of vowels, consonants,
digits and special symbols in a given string.¬¬'''









'''WAP to count the lower case and upper case letters in a string. '''

i=0
upr=0
low=0
while i<len(a):
    if a[i].isupper():
        upr+=1
    else:
        low+=1
    i+=1
print(upr)
print(low)

'''WAP to search a character in a given string.'''

print(x,y)
print(x.count('y'))
if x.count(y)>0:
    print('charecter is there')
else:
    print('char not present')



    
    
     
