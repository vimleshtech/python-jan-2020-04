#1 - x2/2! + x4/4! - x6/6! + …….xn/n!

x = int(input('enter value of x'))
n = int(input('enter value of n'))


o =1

power =2
for i in range(1,n+1):
    temp = x**power
    
    f =1
    tp = power
    while tp>1:
        f*=tp
        tp-=1
        
    r = temp/tp
    if i%2>0:
        o-=r
    else:
        o+=r
        
    power+=2

print(o)



    
