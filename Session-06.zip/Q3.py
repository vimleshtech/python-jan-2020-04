f1 =open(r'C:\Users\vkumar15\Desktop\learning\a.txt')
f2 =open(r'C:\Users\vkumar15\Desktop\learning\b.txt')
f3 =open(r'C:\Users\vkumar15\Desktop\learning\c.txt')

w = open(r'C:\Users\vkumar15\Desktop\learning\out.txt','w')

w.write(f1.read())
w.write(f2.read())
w.write(f3.read())

w.close()
f1.close()
f2.close()
f3.close()

print('all data has saved to out file')



