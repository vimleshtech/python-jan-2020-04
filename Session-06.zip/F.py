'''
n =5
f =1
while n>1:
    f*=n
    n=n-1

print(f)

   1 + x2/2! + x4/4! + x6/6! + …….xn/n! '''
n=int(input('enter the number of terms='))
x=1
f=1
i=0
for i in range(n):
    print('{}+'.format(x**i))
    '''if i%2==0:
        while i>1:
            f*=i
            i=i-1'''
        print('{} / {}'.format(x**i,f),end='+')
    
i+=2
    
