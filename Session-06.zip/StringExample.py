name = input('enter name :')

print(name.upper())
print(name.lower())
print(name.title())
print(name.capitalize())
print(name.swapcase()) #lower to upper and upper to lower 

print(name.strip())
print(name.lstrip())
print(name.rstrip())

print(list(name))

print(name.split(' '))

print(name.count('a'))
print(len(name))


#ord
print(ord('a'))
print(chr(65))

#slicer
print(name[0:4])


#conditional function
if name.isupper():
    print('in upper case ')
else:
    print('in lower case ')

if name.islower():
    print('in lower case ')
else:
    print('in upper case ')


if name.isdigit():
    print('numer')
else:
    print('no number')



if name.istitle():
    print('in title casee ')
else:
    print('not in title case')
    

#ends with
if name.endswith('sinha'):
    print('ending with sinha')
else:
    print('not ending with sinha')

#starts with
if name.startswith('nitin'):
    print('start with nitin')
else:
    print('not start with nitin')
    
    


    

    


    
















