d = {'a':111,'b':'beta',1:344,11:[111,333]}


lc =0
ic = 0
sc=0
for x,y in d.items():
    if type(y) == int:
        ic+=1
    elif type(y) == str:
        sc+=1
    elif type(y) == list:
        lc+=1
        
    #print(type(y))


print(ic)
print(sc)
print(lc)

