
import pandas as pd

d1 ={'eid':[1,2,3],
     'name':['jatin','divya','vidhi'],
     'gender':['male','female','female']}

d2 ={'eid':[1,12,3],
     'name':['jatin1','divya1','vidhi1'],
     'gender':['m','f','f']}


df1 = pd.DataFrame(data=d1)

df2 = pd.DataFrame(data=d2)


df_row = pd.concat([df1, df2])



df_row_reindex = pd.concat([df1, df2], ignore_index=True)



x = pd.concat([df1, df2], axis=1) #axis =1 , col wise 
print(x)



#work like inner join 
y = pd.merge(df1, df2, on='eid')

print(y)



df_inner = pd.merge(df1, df2, on='id', how='inner')
df_right = pd.merge(df1, df2, on='id', how='right')
df_left = pd.merge(df1, df2, on='id', how='left')
df_outer = pd.merge(df1, df2, on='id', how='outer')


df_merge_difkey = pd.merge(df_row, df3, left_on='id', right_on='id')



df_suffix = pd.merge(df1, df2, left_on='id',right_on='id',how='outer',suffixes=('_left','_right'))


  
# Remove column name 'A' 
df.drop(['A'], axis = 1)

# Remove three columns as index base 
df.drop(df.columns[[0, 4, 2]], axis = 1, inplace = True) 

  
# Remove all columns between column index 1 to 3 
df.drop(df.iloc[:, 1:3], inplace = True, axis = 1) 


# Remove all columns between column name 'B' to 'D' 
df.drop(df.ix[:, 'B':'D'].columns, axis = 1) 



--remove row
data = {'name': ['Jason', 'Molly', 'Tina', 'Jake', 'Amy'], 
        'year': [2012, 2012, 2013, 2014, 2014], 
        'reports': [4, 24, 31, 2, 3]}
df = pd.DataFrame(data, index = ['Cochice', 'Pima', 'Santa Cruz', 'Maricopa', 'Yuma'])
df


df.drop(['Cochice', 'Pima'])

df.drop('reports', axis=1)


df[df.name != 'Tina']

#by index
df.drop(df.index[2])
df.drop(df.index[[2,3]])




