import pandas as pd

#read vsv
data = pd.read_csv(r'C:\Users\vkumar15\Documents\Training\Training\Excel VBA\Excel\sales.csv')

print(data.columns)
print(data.head())


#read excel  , there are multiple worksheet in one excel workbook
d = pd.read_excel(r'C:\Users\vkumar15\Documents\Training\Training\Excel VBA\Excel\SalesOrder.xlsx',sheet_name='Sales')

print(d)














