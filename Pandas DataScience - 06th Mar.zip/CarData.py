import pandas as pd

car = pd.read_excel(r'C:\Users\vkumar15\Documents\Training\Training\Excel VBA\Excel\Car_dataset.xlsx',sheet_name='Sheet1')

print(car)

print(car.info())
print(car.describe())


c=car.corr()

print(c)

c.to_csv(r'C:\Users\vkumar15\Documents\Training\Training\Excel VBA\Excel\corr_ex.csv')






