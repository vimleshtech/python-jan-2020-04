
for i in range(1,10):
    print('(',end='')
    for x in range(1,i+1):
        if x<i:
            print(x,end='+') #print in same line
        else:
             print(x,end='') #print in same line
             
    #print() #new line
    print(')+',end='')
    
    
