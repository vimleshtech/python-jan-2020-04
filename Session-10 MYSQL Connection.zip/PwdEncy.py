
pwd='ajfhfgf'

c = list(pwd)
print(c)

enpwd =''
for x in c:
    #print(ord(x)) #return ascii code
    enpwd+=str(ord(x))+'-'

print(enpwd)


l = enpwd.split('-')
print(l)

s =''
for w in l[:-1]:
    #print(chr(int(w)))
    s=s+chr(int(w))

print(s)

    
    
    
    
          

