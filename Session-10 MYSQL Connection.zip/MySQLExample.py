import mysql.connector as c

con = c.connect(host='localhost',database='mypython',user='root',password='root')

o = con.cursor() #cursor will run sql statement 
o.execute('select * from users')

data = o.fetchall()
print(data)

for r in data:
    print(r[0] , r[1])
    


#save data
i = input('enter eid :')
n = input('enter name :')

o.execute("insert into users(uid,name) values({},'{}');".format(i,n))
con.commit()



    


		
