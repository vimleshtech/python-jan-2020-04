for x in range(10):
    if x<9:
        print(x,end=',')
    else:
        print(x,end='')


#or
print()
s = ''
for x in range(10):
    s+=str(x)+','

print(s)
print(s[:-1])


        
    
