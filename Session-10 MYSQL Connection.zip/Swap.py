

a=3
b =5


print(a)
print(b)

b,a =a,b
print(a)
print(b)
