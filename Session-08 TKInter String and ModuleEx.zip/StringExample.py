s = input('enter data ')

print(s.upper())
print(s.lower())
print(s.title())
print(s.capitalize())
print(s.swapcase())


print(s.strip())
print(s.lstrip())
print(s.rstrip())

print(len(s))
print(s.replace('a','xy'))
print(s.count('a'))

print(list(s))

w = s.split('a')#default seperator is space
print(w)



print(ord('A'))
print(chr(97)) # 13 enter , 32  space


print(s[0:3])
print(s[-1])
print(s[::-1])



if s.isdigit():
    print('numeric value')
else:
    print('not numeric')


if s.isupper():
    print('in upper case')
else:
    print('other case')


if s.islower():
    print('in lower casae')
else:
    print('in other case')





if s.endswith('z'):
    print('ending with z')
else:
    print('ending with other ')


    









