import os
import shutil


f = os.listdir(r'C:\Users\vkumar15\Desktop\Adda52-Automation\Adda52')
for x in f:
    if x.endswith('xls'):
        #print(x)
        shutil.copy(r'C:\Users\vkumar15\Desktop\Adda52-Automation\Adda52\\'+x,r'C:\Users\vkumar15\Desktop\\')
        
    
