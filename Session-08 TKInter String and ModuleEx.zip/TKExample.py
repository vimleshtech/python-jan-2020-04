from tkinter import *

t = Tk()
t.title('Test Application')


fn = Label(text='enter fname ')
fn.pack()

tfn = Entry()
tfn.pack()

ln = Label(text='enter lname ')
ln.pack()

tln = Entry()
tln.pack()



lbl = Label()
lbl.pack()

def fun1():
    print('you have clicked on button !')
    a = tfn.get()
    b = tln.get()
    name =a+' '+b
    print('your full name is ',name)
    lbl.configure(text=name)
    
b = Button(text='CLick Me',command=fun1)
b.pack()


t.mainloop()



