s = input('enter data ')

o = s.split('.')
print(o)

i =1
while i<len(o):
    if o[i-1] > o[i]:
        print('previous number is greater number from next numeber ')
    elif  o[i-1] < o[i]:
        print('previous number is less than from next numeber ')
    else:
        print('both number are equal ')
    i =i+1


        
    
