x = int(input('enter num :'))
n = int(input('number of times :'))
f =2 

o =1
for i in range(n):

    p = x**f

    fact = 2
    out =1
    while fact<=f:
        out*=fact
        fact=fact+1
        

    f =f+2

    o+=p/out        

print(o)

    

    

