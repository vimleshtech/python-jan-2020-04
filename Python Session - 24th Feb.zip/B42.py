i =1
while i<10000:
    print('a',end='')
    i=i+1
    
