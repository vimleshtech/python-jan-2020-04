a='ABCDEFG'
#a='FEDCBA'

for i in range(0,len(a)):
    
    r = a[::-1]

    if i==0:
        s =  a+r[1:]
    else:
        s =  a[:i*-1]+'  '*i +r[i:]
    
    print(s)
    
    
    
    


