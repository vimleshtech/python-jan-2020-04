#CRUD :  Create , Read,  update, delete

import mysql.connector as c
con = c.connect(host='localhost',database='hrms',user='root',password='root')
cur = con.cursor()


while True : #10==10:

    ch = input('press 1 for create 2 for read 3 for update 4 delete and 0 for exit ')

    if ch =='1':

        i =input('enter eid ')
        n =input('enter name ')
        e =input('enter email ')
        p =input('enter pwd')
        
        cur.execute("insert into users(uid,name,email,pwd) values({},'{}','{}','{}')".format(i,n,e,p))
        con.commit()
        print('data is saved')
        
        
        
    elif ch=='2':
        cur.execute("select * from users")
        data = cur.fetchall()
        for r in data:
            print(r)
            

        

    elif ch=='3':
        i =input('enter eid ')
        n =input('enter name ')
        cur.execute("update users set name = '{}' where uid ={}".format(n,i))
        con.commit()
        print('data is updated ')
        


    elif ch=='4':
        i = input('enter uid to remove ')
        cur.execute("delete from users where uid ="+i)
        con.commit()
        print('data is deleted ')
        

        

    elif ch=='0':
        print('app will be terminated !')
        
        break 
    else:
        print('invalid choice !!! plz try again !!!')
        

        
    
    
    
    

