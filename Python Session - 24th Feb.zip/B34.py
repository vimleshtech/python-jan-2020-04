n1 = int(input('enter data :'))
n2 = int(input('enter data :'))

choice = int(input('press 1 for add 2 for sub 3 for mul 4 for div and 5 for reminder'))


n = 0
if choice==1:
    n = n1+n2
    
elif choice==2:
    n = n1-n2
elif choice==3:
    n = n1*n2
elif choice==4:
    n = n1/n2
elif choice==5:
    n = n1%n2
else:
    print('invalid choice ')
    
print(n)



