a =4
b =554

c =a+b
print(c)
