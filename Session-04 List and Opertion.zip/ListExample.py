sales = [111,3,34,5,6,653,566,5]

print(len(sales)) #return len/size

print(sales.count(5))#find 5 and return count


print(max(sales))
print(min(sales))

print(sum(sales))


##sort
sales.sort()
print(sales)

#reverse
sales.reverse()
print(sales)

##extend
a =[11,33,5]
b =[545,66]
print(a)
print(b)

a.extend(b)
print(a)


#
a =[1112,4,5,66]
b =a  #assign same memory to b 
print(a)
print(b)

b[1] = 9000

print(a)
print(b)


##
a =[1112,4,5,66]
b =a.copy() #create new copy of data for b 
print(a)
print(b)

b[1] = 9000

print(a)
print(b)


### add value at last
sales.append(1111)
sales.append(1111)
print(sales)

sales.pop() #remove from last
print(sales)


##
sales.insert(2,10) #add new value at given position 
print(sales)

#remove
if 11 in sales:
    sales.remove(11) #remove if exist or throw error
    
print(sales) 


##slicer
print(sales)
print(sales[0]) #first data 
print(sales[-1]) #last data 

print(sales[0:4]) #0 to <4
print(sales[:4]) #0 to <4
print(sales[4:-3])

#print in reverse
print(sales[::-1])


















