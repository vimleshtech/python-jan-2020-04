
sales = [] #empty lsit

for i in range(10):# 0 to 9
    x = int(input('enter data :'))
    sales.append(x)


print(sales)

for y in sales:
    print(y)
    

