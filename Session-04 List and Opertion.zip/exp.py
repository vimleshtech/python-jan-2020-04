a=[12,14,56,78,43,65]

m = 0
for x in a:
    if m<x:
        m = x

print(m)
print(a.index(m))

        

m2 = 0
for x in a:
    if m2<x and x<m:
        m2 = x

 
    

print(m2)
print(a.index(m2))

    

###
for i in range(len(a)-1,-1,-1): #from,<to,increment/derement
    print(a[i])
    

###
d = []
for x in range(10): #0 1 2 ... 9
    y = int(input('enter data :'))
    d.append(y)
    d.sort()
    print(d)
    
    



    
               
    
