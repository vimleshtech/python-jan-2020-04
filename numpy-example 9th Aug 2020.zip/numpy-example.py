#!/usr/bin/env python
# coding: utf-8

# In[2]:


a =1
b =4
c =a+b
print(c)


# In[3]:


#load library 
import numpy as np  #np is an alieas


# In[10]:


#create array using range function 
x = np.arange(10) #generate the sequence number from 0 to 9 
print(x)

x = np.arange(1,20) #generate arry for given range
print(x)

x =np.arange(1,10,.5) #start from 1 and till <10, and increment by .5
print(x)

#type
print(type(x))

#diff between list and array
#list can store mix type data  [11,'ff',True]
#array is store one type data  [11,22,55,677]  ['11','aa']

#list 
l =[11,33,667]
print(l)
print(type(l))
print(l*2)  #double the list

#array
x = np.arange(1,20) #generate arry for given range
print(x)
print(x*2) #multiply every value by 2


# In[12]:


#convert list to array
a =[11,2,46,77,33,6676]
print(a)

x = np.array(a)  #convert list to array 
print(x)


# In[16]:


#shape  and reshape
print(x.shape)  # 6 rows (one dimenssion array)

#reshape
y = np.array(x).reshape(-1,3)  #by row   , and 3 cols
print(y)

#convert in given row and col shape
z = np.array(x).reshape(3,2)  # 3 rows and 2 cols
print(z)

print(z.shape)


# In[18]:


#generate the series of 0 and 1
x = np.zeros(10)
print(x)

y = np.ones(10)
print(y)


# In[23]:


#array operation 
z = np.array([111,33,4,6,7,3322])
print(z)
print(z*3) #multiply every element by 3

print(z*1.30)

print(z/3)


y = np.array([111,33,4,6,7,3322]).reshape(2,3)
print(y)
print(y*5)


# In[26]:


a = np.array([[1,2,3],[77,8,9]])
b = np.array([[11,2,3],[7,18,90]])

print(np.divide(a,b))
print(np.add(a,b))
print(np.multiply(a,b))


# In[34]:


#data type 
x = np.array([11,44,55,77],dtype=float)
print(x)

x = np.array([11,44,55,77],dtype=object)
print(x)


y = ['11','22','33']
x = np.array(y,dtype=float)
print(x)


# In[43]:


#handler nan value or play with nan and 0 value
x = np.array([11,33,56,np.nan,66,333,np.nan,0,5,np.nan])
print(x)

#boolean index 
print(np.isnan(x)) #isnan() is method or function , all nan will be mark is True 

#print all nan values only
print(x[np.isnan(x)])

#print all non nan value / discard nan value
print(x[~np.isnan(x)])

##filter zero
y = x.nonzero() #return index of all non zero
print(y)

#get all non zero
print(x[x.nonzero()])

#discard all 0 and nan
m = x[~np.isnan(x)]  #discard all nan 
print(m)

print(m[m.nonzero()]) #discard all 0 




