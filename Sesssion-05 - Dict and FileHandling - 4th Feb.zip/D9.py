
a =[5,66,444443,55,666,111,33,4,5]


n = int(input('enter n :'))

print(a)
b = a[0:n]
a[0:n]=[]

a.extend(b)
print(a)


