for x in range(1,10): #1 to <5
    print('(',end='')
    
    for y in range(1,x+1):  # 1 to <2
        if y<x:
            print(y,end='+') #end='' don't change line
        else:
            print(y,end='')
            
    print(')+',end='')
    
    
