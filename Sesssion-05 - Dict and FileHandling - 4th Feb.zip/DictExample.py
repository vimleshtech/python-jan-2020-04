#dictionary
d ={'a':100,'b':'beta',11:[111,3,44,5666]}

print(type(d))

print(d) #print all
print(d['a'])

d['a'] =900 #modify value on exiting key
print(d)


#add new key , key should be unique
d['t'] ='tata'
print(d)

print(d.keys())

print(d.values())
print(d.items())


####iterate key and value together
for x,y in d.items():
    #print(x) #keys
    #print(y) #values
    if y =='beta':
        print(x)

#or
k = list(d.keys())
v = list(d.values())
print(k)
print(v)

print(k[v.index('tata')])

###remove the item, key

del d['t']
print (d)


#del d
#print(d)









        
        
    
    
