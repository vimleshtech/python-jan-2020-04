
#read text file

f =open(r'C:\Users\vkumar15\Desktop\Links & Imps.txt','r') #default mode is read

#print(f.read())
#print(f.readline())
#print(f.readline())

data = f.readlines()

f.close()

#print(data[41])

#wap to get word count
wc = 0
#search given word 
for r in data:
    #print(r)
    words = r.split(' ')
    wc =wc+len(words)
    if '5' in words:
        print('5 is match')
        
    

print('row count ',len(data))
print('word count ',wc)

###or
with open(r'C:\Users\vkumar15\Desktop\Links & Imps.txt','r')  as f:
    print(f.read())
    





