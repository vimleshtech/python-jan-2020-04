#
w = open(r'C:\Users\vkumar15\Desktop\out.txt','a') #create file if not exist or overwrite if exist
#append

#w.write('hi\n')
#w.write('hifdfdf \n')

while True:
    ch = input('enter y to continue and n for exit ')
    if ch =='y':
        d = input('enter data :')
        w.write(d+'\n')
        
    elif ch=='n':
        break
    else:
        print('invalid choice, enter again ')
        

w.close()

print('file is saved ')
