def add(a,b=0,c=0,d=0):
    print(a+b+c+d)


def mul(*a): #default type is tuple
    print(a)
    print(type(a))
    f = 1
    for x in a:
        f =f*x

    print(f)

