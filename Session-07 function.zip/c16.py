
a ='hi'

b = a

print(a)
print(b)

b ='1'
print(a)
print(b)
