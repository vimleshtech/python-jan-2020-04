import mylib

mylib.add(11,3344)




##or
from mylib import add,mul
mul(11,44,556)

#
from mylib import *
add(11,344)

#
import mylib as l
l.add(44,50)
