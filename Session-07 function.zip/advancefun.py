def add(a,b=0,c=0,d=0):
    print(a+b+c+d)


def mul(*a): #default type is tuple
    print(a)
    print(type(a))
    f = 1
    for x in a:
        f =f*x

    print(f)
    

def fact(n):
    if n ==1:
        return n
    else:
        return n*fact(n-1) #6*5*4*3*2*1
    
tax = lambda amt,a : amt*.18

'''
def tax(amt):
 t = amt*.18
 return t
'''

add(1,33)
add(1)
add(1,34,445)
add(1,34,445,5)

mul(11,33,5)
mul(11,33,5,444,6,777)


f = fact(6)
print(f)

print(tax(10000,1))

    
