#no argument no return
def welcome():
    print('welcome to function world ..')
    print('this module contains following function i. welcome ii. getdata iii. add iv. sub ... ')

#no argument with return
def getData():
    a = input('enter data ')
    b = input('enter data ')
    return int(a), int(b)

#argument with no return     
def add(n1,n2):
    print(n1+n2)
    
#argument with return
def sub(a,b):
    return a-b


welcome()
welcome()

x,y =getData()
print(x*y)


x,y =getData()
print(x+y)


add(11,44)
add(55,666)



o = sub(44,56)
print(o)
add(o,10)





    
