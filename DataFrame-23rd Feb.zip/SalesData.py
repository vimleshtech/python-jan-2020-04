import pandas as pd
import matplotlib.pyplot as plt

sales = pd.read_excel(r'C:\Users\vkumar15\Documents\Training\Training\Excel VBA\Excel\SalesOrder.xlsx',sheet_name='Sales')
print(sales)



#sales.plot()
#sales.plot(kind='bar')
#sales.plot(kind='bar',subplots=True)
#sales.plot(kind='bar',subplots=True,layout=(3,2))
#
#sales[['TOTAL','SALE_AMT','QTY']].plot(kind='box')

x = sales[['TOTAL','SALE_AMT','QTY']]
x.plot(kind='box')



plt.show()



