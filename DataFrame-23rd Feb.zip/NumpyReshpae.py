import numpy as np
  
array = np.arange(8) 
print("Original array : \n", array) 

array = np.arange(8).reshape(-1, 4)
print(array)

array = np.arange(8).reshape(2, 4)
print(array)


array = np.arange(8).reshape(2, -1)
print(array)



array = np.arange(8).reshape(-1, 2,order='C')
print(array)

# shape array with 2 rows and 4 columns 
array = np.arange(8).reshape(2, 4) 
print("\narray reshaped with 2 rows and 4 columns : \n", array) 
  
# shape array with 2 rows and 4 columns 
array = np.arange(8).reshape(4 ,2) 
print("\narray reshaped with 2 rows and 4 columns : \n", array) 
  
# Constructs 3D array 
array = np.arange(8).reshape(2, 2, 2) 
print("\nOriginal array reshaped to 3D : \n", array)
