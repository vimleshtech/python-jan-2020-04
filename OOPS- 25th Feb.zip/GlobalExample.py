
def test():
    x =100 #x is local variable 
    print(x)

    #declre global variable
    global m
    m =100
    print(m)
        

test()
print(m)

#print(x) #error

