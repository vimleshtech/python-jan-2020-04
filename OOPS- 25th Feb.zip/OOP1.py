class emp:

    def newemp(s):
        print('in new emp')
        print(s)

        #input and store on local variable
        #now store on memory location / make it global 
        s.eid = input('enter eid :')
        s.name = input('enter name :')
        s.sal =  int(input('enter sal :'))
        

    def show(self):
        print('in show fun ')
        print(self)

        print('eid is ',self.eid)
        print('name is ',self.name)
        print('sal is ',self.sal)
        print('monthly sal is ',self.month)
        print('yearly sal is ',self.ysal)
        


    def cal(self):
        self.hra = self.sal*.40
        self.da = self.sal*.20
        self.month  =  self.hra + self.da+ self.sal
        self.ysal = self.month*12
        
    def __init__(s):
        print('object is creaetd ')
        s.eid = 0
        s.name =''
        s.sal = 0

    def __del__(s):
        print(s, ' is removed,now you cannot use further ')
        
#create an object of class
o = emp()
print(o)  #print object address 
o.newemp()
o.cal()

o.show()


del o
#o.show() #error


