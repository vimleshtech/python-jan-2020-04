n =45

print(n*2)
print(n**3) #power
print(n/10)
print(n//10)
print(n%10)


#assigment
a =10
#a+=1
a =a+1

print(a)
