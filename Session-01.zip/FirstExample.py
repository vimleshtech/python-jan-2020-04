print('hello') #show message 
print("hello") #show message 

msg    =     'hello'
print(msg)  #show message from variable 



#wap to print sum two numbers
a =11
b =55
c =a+b
print(c)
