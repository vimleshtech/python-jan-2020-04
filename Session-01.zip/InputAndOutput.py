print('hi')
print('Raman')

#print in same line
print('hi',end='')
print('Raman')


##
name ='Raman'
print('your name is ',name)


#input example
name =input('enter name :')
salary =input('enter salary :')

print(type(name))
print(type(salary))

print('name is ',name)
print('salary is ',salary)



