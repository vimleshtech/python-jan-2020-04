a =int( input('enter num :'))
b = int(input('enter num :'))



c =a+b
print('sum of two numbers ',c)

