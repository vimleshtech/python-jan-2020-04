sales_amt = int(input('enter sales amt :'))

tax = 0

if sales_amt>1000:
        tax = sales_amt*.18 #18% on sales amt
else:
        tax = sales_amt*.12
        
    
total_amt = sales_amt+tax
print('total amt is ',total_amt)

    


