for x in range(10): #0 to 9
    print(x)
    


for x in range(1,11):
    print(x)
    

#in rev
for x in range(10,0,-1):
    print(x)
    
