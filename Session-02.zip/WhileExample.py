#print series from 1 to 10
x =1
while x<=10:
    print(x)
    x+=1
    

#print same line
x =1
while x<=10:
    print(x,end='\t')
    x+=1


#print in reverse order
x =10
while x>0:
    print(x)
    x-=1
    

