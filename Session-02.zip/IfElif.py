sales_amt = int(input('enter sales amt :'))

tax = 0

if sales_amt>1000:
        tax = sales_amt*.18 #18% on sales amt
elif sales_amt>500:
        tax = sales_amt*.12
elif sales_amt>200:
    tax = sales_amt*.10    
else:
    tax = sales_amt*.05

    
total_amt = sales_amt+tax
print('total amt is ',total_amt)

    


