#wap to print table of given
t = int(input('enter num :'))

x =1
while x<=10:
    #print(x*t)
    print('{} * {} = {}'.format(t,x,x*t))
    x+=1


#wap get sum of all even and odd numbers between two given range
x = int(input('enter first num '))
y = int(input('enter 2nd num '))

se =0
so = 0
while x<=y:

    if x%2 ==0: #if no is even
        se+=x
    else:
        so+=x

    x+=1


print('sum of all even number ',se)
print('sum of all odd number ',so)



